﻿using System.Reflection;
[assembly: AssemblyTitle("KSFrameowork (http://github.com/mr-kelly/KSFramework)")]
[assembly: AssemblyDescription("KSFramework - KEngine + SLua")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Kelly")]
[assembly: AssemblyProduct("KSFramework")]
[assembly: AssemblyCopyright("Copyright @ Kelly<23110388@qq.com> 2015-2016")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("0.11.*")]
namespace KSFramework { public class KSFrameworkInfo { public static readonly string Version = "0.11.*"; } }
