﻿using UnityEngine;

namespace KSFramework
{
    public class UILuaOutletCollection:MonoBehaviour
    {
        public UILuaOutlet[] UILuaOutlets;
    }
}