﻿/* 
 LuaFramework Code By Jarjin lee
*/
using System;

public interface ICommand {
	void Execute(IMessage message);
}

