﻿using System;
using LuaInterface;

public static class LuaBinder
{
	public static void Bind(LuaState L)
	{
		throw new LuaException("Please generate LuaBinder files first!");
	}
}
